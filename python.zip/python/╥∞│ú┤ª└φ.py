def get_integer_input(prompt):
    while True:
        try:
            return int(input(prompt))
        except ValueError:
            print("Please enter a valid integer.")

# 获取用户输入
user_input = get_integer_input("Enter an integer: ")
print(f"You entered: {user_input}")