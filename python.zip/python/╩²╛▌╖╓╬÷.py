import pandas as pd

# 读取CSV文件
df = pd.read_csv('data.csv')

# 显示前5行
print(df.head())