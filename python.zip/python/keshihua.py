import matplotlib.pyplot as plt

# 数据
x = [1, 2, 3, 4, 5]
y = [1, 4, 9, 16, 25]

# 绘制折线图
plt.plot(x, y)
plt.title('Square Numbers')
plt.xlabel('Value')
plt.ylabel('Square')
plt.show()