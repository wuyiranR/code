import socket

# 创建socket对象
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 绑定端口
server_socket.bind(('localhost', 12345))

# 监听
server_socket.listen(5)

while True:
    # 建立客户端连接
    client_socket, addr = server_socket.accept()
    print(f"连接地址: {addr}")
    
    # 接收小于 1024 的数据量
    msg = client_socket.recv(1024)
    
    print(f"收到消息：{msg.decode('utf-8')}")
    client_socket.send('消息收到'.encode('utf-8'))
    
    # 关闭连接
    client_socket.close()