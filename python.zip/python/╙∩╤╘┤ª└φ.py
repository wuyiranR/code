import nltk
from nltk.tokenize import word_tokenize
from nltk import pos_tag

# 句子
sentence = "The quick brown fox jumps over the lazy dog."

# 分词
words = word_tokenize(sentence)

# 词性标注
tagged_words = pos_tag(words)

print(tagged_words)