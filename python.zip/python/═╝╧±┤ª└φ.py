from PIL import Image

# 打开图像文件
img = Image.open('image.jpg')

# 显示图像
img.show()