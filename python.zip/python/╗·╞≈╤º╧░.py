from sklearn.linear_model import LinearRegression
import numpy as np

# 创建一些数据
X = np.array([[1], [2], [3], [4]])
y = np.array([2, 4, 6, 8])

# 创建并训练模型
model = LinearRegression()
model.fit(X, y)

# 预测新数据
print(model.predict([[5]]))