from cryptography.fernet import Fernet

# 生成密钥
key = Fernet.generate_key()
cipher_suite = Fernet(key)

# 加密
text = "Hello World"
encrypted_text = cipher_suite.encrypt(text.encode())
print("Encrypted:", encrypted_text)

# 解密
decrypted_text = cipher_suite.decrypt(encrypted_text).decode()
print("Decrypted:", decrypted_text)